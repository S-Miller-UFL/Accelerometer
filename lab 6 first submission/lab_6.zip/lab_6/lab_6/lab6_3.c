//*******************************************
//Lab 6, Section 3
//Name: Steven Miller
//Class #: 11318
//PI Name: Anthony Stross
//Description: allows communication with IMU
//*******************************************

/********************************DEPENDENCIES**********************************/

#include "lsm6ds3tr.h"
#include "lsm6ds3tr_registers.h"
#include <avr/io.h>
#include "spi.h"

/*****************************END OF DEPENDENCIES******************************/

int main(void)
{
	spi_init();
	while(1)
	{
		spi_write(0x2a);
	}
	return 0;
}