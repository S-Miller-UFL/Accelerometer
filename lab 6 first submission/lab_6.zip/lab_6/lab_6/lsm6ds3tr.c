/*------------------------------------------------------------------------------
  lsm6ds3tr.c --
  
  Description:
    Brief description of file.
	  
	  Extended description, if appropriate.
  
  Author(s):
  Last modified by: Dr. Eric M. Schwartz
  Last modified on: 8 Mar 2023
------------------------------------------------------------------------------*/

/********************************DEPENDENCIES**********************************/

#include <avr/io.h>
#include "lsm6ds3tr.h"
#include "lsm6ds3tr_registers.h"

/*****************************END OF DEPENDENCIES******************************/


/*****************************FUNCTION DEFINITIONS*****************************/

void lsm_write(uint8_t reg_addr, uint8_t data)
{
	//enable imu by enabling chip select
	
	//send over the address bits
	//then, send over the data bits
	//disbale imu by disabling chip select
	
}

uint8_t lsm_read(uint8_t reg_addr)
{
	//enable imu by enabling chip select
	
	//send over the address bits
	//read in the data bits
	//disbale imu by disabling chip select
	
	
}

/***************************END OF FUNCTION DEFINITIONS************************/